package com.talkaurelia.karbi

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingWelcomeSpeech: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)

        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        val bridge = NativeAppBridge(this)
        webView.addJavascriptInterface(bridge, "AndroidBridge")
        webView.addJavascriptInterface(bridge, "AndroidKarbiBridge")
        webView.addJavascriptInterface(bridge, "AndroidInterface")

        webView.loadUrl("file:///android_asset/www/index.html")

        // Mobile Back button steps back pages inside the web app instead of exiting the app
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "(function(){ if(window.handleAndroidBackButton){ return window.handleAndroidBackButton(); } return false; })()",
                    null
                )
            }
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("en", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            tts?.setSpeechRate(0.92f)
            ttsReady = true
            pendingWelcomeSpeech?.let {
                speakOut(it, "en-IN")
                pendingWelcomeSpeech = null
            }
        }
    }

    private fun speakOut(text: String, langHint: String) {
        if (!ttsReady) {
            pendingWelcomeSpeech = text
            return
        }
        val clean = text.split("/")[0].replace(Regex("\\([^)]*\\)"), "").trim()
        if (clean.isEmpty()) return
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "ta_utt_" + System.currentTimeMillis())
    }

    inner class NativeAppBridge(private val context: Context) {
        private val prefs = context.getSharedPreferences("talk_aurelia_prefs_v2", Context.MODE_PRIVATE)

        @JavascriptInterface
        fun speakText(text: String, lang: String?) {
            runOnUiThread { speakOut(text, lang ?: "en-IN") }
        }

        @JavascriptInterface
        fun speakP1P2(text: String, lang: String?) {
            runOnUiThread { speakOut(text, lang ?: "en-IN") }
        }

        @JavascriptInterface
        fun playAudio(text: String) {
            runOnUiThread { speakOut(text, "en-IN") }
        }

        @JavascriptInterface
        fun savePref(key: String, value: String) {
            prefs.edit().putString(key, value).apply()
        }

        @JavascriptInterface
        fun loadPref(key: String): String {
            return prefs.getString(key, "") ?: ""
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread {
                finishAffinity()
            }
        }

        @JavascriptInterface
        fun onExitClick() {
            runOnUiThread {
                finishAffinity()
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
